import 'package:sqlcool/sqlcool.dart';

Db db = Db();
