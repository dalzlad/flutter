import 'package:sqlcool/sqlcool.dart';

final Db db = Db();
